jQuery(".star1").on("click", function(){
    jQuery(".star1").removeClass("green-star");
    (this).addClass("green-star");
});
jQuery(".star2").on("click", function(){
    jQuery(".star2").removeClass("green-star");
    (this).addClass("green-star");
});
jQuery(".star3").on("click", function(){
    jQuery(".star3").removeClass("green-star");
    (this).addClass("green-star");
});
jQuery(".star4").on("click", function(){
    jQuery(".star4").removeClass("green-star");
    (this).addClass("green-star");
});